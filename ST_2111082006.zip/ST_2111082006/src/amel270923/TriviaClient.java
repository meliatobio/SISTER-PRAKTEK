/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amel270923;

/**
 *
 * @author AMELIA MENSON
 */
import java.io.*;
import java.net.*;

public class TriviaClient {
    private static final String SERVER_ADDRESS = "127.0.0.1";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            String userCommand;

            while (true) {
                System.out.println("Ketik 'permintaan' untuk pertanyaan atau 'jawaban' untuk jawaban:");
                userCommand = userInput.readLine();

                if (userCommand != null) {
                    out.println(userCommand);

                    if (userCommand.equals("permintaan")) {
                        String question = in.readLine();
                        System.out.println("Pertanyaan: " + question);
                    } else if (userCommand.equals("jawaban")) {
                        String response = in.readLine();
                        System.out.println(response);
                    } else {
                        System.out.println("Perintah tidak valid.");
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

