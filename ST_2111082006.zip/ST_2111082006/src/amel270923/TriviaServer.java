/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amel270923;

/**
 *
 * @author AMELIA MENSON
 */
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TriviaServer {
    private static final int PORT = 12345;
    private static List<String> pertanyaan = new ArrayList<>();
    private static List<String> jawaban = new ArrayList<>();
    private static Random random = new Random();

    public static void main(String[] args) {
        initializeQuestions();

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server sedang mendengarkan...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Terhubung dengan " + clientSocket.getInetAddress());
                handleClient(clientSocket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void initializeQuestions() {
        // Inisialisasi pertanyaan dan jawaban
        pertanyaan.add("Apa ibukota Indonesia?");
        jawaban.add("1#Jakarta");

        pertanyaan.add("Siapa presiden Indonesia saat ini?");
        jawaban.add("2#Joko Widodo");

        pertanyaan.add("Siapa pembuat Java?");
        jawaban.add("3#James Gosling");

        pertanyaan.add("Apa bahasa pemrograman yang digunakan untuk membuat aplikasi web?");
        jawaban.add("4#HTML");

        pertanyaan.add("Apa singkatan dari HTML?");
        jawaban.add("5#Hypertext Markup Language");
    }

    private static void handleClient(Socket clientSocket) throws IOException {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.equals("permintaan")) {
                    sendRandomQuestion(out);
                } else if (inputLine.startsWith("jawaban")) {
                    handleAnswer(inputLine, out);
                } else {
                    out.println("Perintah tidak valid.");
                }
            }
        }
    }

    private static void sendRandomQuestion(PrintWriter out) {
        int randomIndex = random.nextInt(pertanyaan.size());
        String randomQuestion = pertanyaan.get(randomIndex);
        out.println(randomQuestion);
    }

    private static void handleAnswer(String inputLine, PrintWriter out) {
        String[] parts = inputLine.split("#");
        if (parts.length == 2) {
            int questionNumber = Integer.parseInt(parts[0].substring(7));
            String answer = parts[1];
            if (questionNumber >= 1 && questionNumber <= pertanyaan.size()) {
                if (jawaban.get(questionNumber - 1).equalsIgnoreCase(answer)) {
                    out.println("Kerja yang bagus!");
                } else {
                    out.println("Jawaban salah. Coba lagi.");
                }
            } else {
                out.println("Nomor pertanyaan tidak valid.");
            }
        } else {
            out.println("Format jawaban tidak valid.");
        }
    }
}
