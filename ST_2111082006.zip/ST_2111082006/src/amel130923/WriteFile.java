/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amel130923;
import java.io.*;
/**
 *
 * @author AMELIA MENSON
 */
public class WriteFile {
            public static void main(String args[]) throws IOException {
                
            }
}
