/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amel041023;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author AMELIA MENSON
 */
public class ChatServer {
    
    private static final int port = 12345;
    private static Set<PrintWriter> clientWriters = new HashSet<>();
    
    public static void main(String[] args) {
        System.out.println("Server Running");
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            while(true) {
                new ClientHandler(serverSocket.accept()).start();
            }
        } catch (IOException ex) {
            e.printStackTrace();
        }
    }
    
    private static class ClientHandler extends Thread {
     
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        
        public ClientHandler (Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);
                synchronized(clientWriters){
                    clientWriters.add(out);
                }
            
                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println("Received: " + message);
                    broadcastMessage(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if(out !=null){
                    synchronized(clientWriters) {
                        clientWriters.remove(out);
                    }
                }
                
                try {
                    socket.close();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        }
        
        private void brodcastMessage(String message) {
            synchronized(clientWriters){
                for(PrintWriter writer:clientWriters){
                    writer.println(message);
                    writer.flush();
                }
            }
        }

        private void broadcastMessage(String message) {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }

    private static class e {

        private static void printStackTrace() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public e() {
        }
    }
}
    